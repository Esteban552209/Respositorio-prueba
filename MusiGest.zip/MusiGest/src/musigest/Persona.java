/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package musigest;

import javax.swing.JOptionPane; 
/**
 *
 * @author ea054
 */

public abstract class Persona {

    private int id;
    private String nombre;
    private String correo;
    private String contrasena;

    public Persona(int id, String nombre, String correo, String contrasena) {
    this.id = id;
    this.nombre = nombre;
    this.correo = correo;
    this.contrasena = contrasena;
    }
   
    public int getId() {
    return id;
    }

    public String getNombre() {
    return nombre;
    }

    public String getCorreo() {
    return correo;
    }

    public String getContrasena() {
    return contrasena;
    }

    public void setContrasena(String contrasena) {
    this.contrasena = contrasena;
    }

    public void iniciarSesion() {
    JOptionPane.showMessageDialog(null, "¡Bienvenido/a " + nombre + "!");
    }

    public void cerrarSesion() {
    JOptionPane.showMessageDialog(null, "Adiós " + nombre + ", cerrando sesión...");
    }

    public void cambiarContrasena() {
    String nueva = JOptionPane.showInputDialog(null, "Ingresa tu nueva contraseña:");
    this.contrasena = nueva;
    JOptionPane.showMessageDialog(null, "Contraseña cambiada con éxito.");
    }
}