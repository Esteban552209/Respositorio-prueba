/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package musigest;
/**
 *
 * @author ACCN0
 */
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Artista {
    private int idArtista;
    private String nombre;
    private String paisOrigen;
    private String descripcion;
    private ArrayList<Album> albums;

    public Artista(int idArtista, String nombre, String paisOrigen, String descripcion) {
        this.idArtista = idArtista;
        this.nombre = nombre;
        this.paisOrigen = paisOrigen;
        this.descripcion = descripcion;
        this.albums = new ArrayList<>();
    }

    public int idArtista() {
        return idArtista;
    } 
     
    public String getNombre() {
        return nombre;
    }

    public String getPaisOrigen() {
        return paisOrigen;
    }

    public String getDescripcion() {
        return descripcion;
    }
    
    public ArrayList<Album> getAlbums(){
        return albums;
    }
    
    public void agregarAlbum(Album album) {
        albums.add(album);
    }

    public void eliminarAlbum(Album album) {
        albums.remove(album);
    }
    
    public void obtenerAlbums(){
        if(this.albums.isEmpty()){
            JOptionPane.showMessageDialog(null, "El artista no tiene albumes");
        return;
        }else{
            String listaAlb = "";
            for(int i=0; i<this.albums.size(); i++){
                Album a = this.albums.get(i);
                listaAlb += (i + 1) + ". " + a.getTitulo() + " (" + a.getAnioLanzamiento() + ")\n";
            }
            
            JOptionPane.showMessageDialog(null, listaAlb);
        }
    }
    
}


