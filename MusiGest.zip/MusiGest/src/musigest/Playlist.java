/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package musigest;
import java.util.ArrayList; 

/**
 *
 * @author USER
 */
public class Playlist {
    private int idPlaylist;
    private String nombre;
    private String fechaCreacion; 
    private ArrayList<Cancion> canciones;

    public Playlist(int idPlaylist, String nombre, String fechaCreacion){
    this.idPlaylist= idPlaylist;
    this.nombre= nombre;
    this.fechaCreacion= fechaCreacion; 
    this.canciones = new ArrayList<>();
    }
    
    public String getNombre(){
    return nombre;
    }
    
    public ArrayList<Cancion> getCanciones(){
    return canciones;
    }
    
    public void agregarCancionPlaylist(Cancion cancion){
    this.canciones.add(cancion);
    }
    
    public void quitarCancionPlaylist(Cancion cancion){
    this.canciones.remove(cancion);
    }
}
   

