/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package musigest;

import java.util.ArrayList; 
import javax.swing.JOptionPane;
/**
 *
 * @author ea054
 */
public class Usuario extends Persona{
    
    private String fechaRegistro;
    private ArrayList<Artista> artistas;
    private ArrayList<Playlist> playlists;
    
    public Usuario(int id, String nombre, String correo, String contrasena, String fechaRegistro){
    super(id, nombre, correo, contrasena);
    this.fechaRegistro = fechaRegistro;
    this.artistas = new ArrayList<>();
    this.playlists = new ArrayList<>();
    }
    
    public String getFechaRegistro() {
    return fechaRegistro;
    }
    
    // ARTISTAS
    
    public void crearArtista(){
    int idArtista = Integer.parseInt(JOptionPane.showInputDialog("Digite el id del artista"));
    String nombre = JOptionPane.showInputDialog("Nombre del nuevo artista");
    String paisOrigen = JOptionPane.showInputDialog("Pais de origen del nuevo artista");
    String descripcion = JOptionPane.showInputDialog("Descripcion del nuevo artista");
    
    Artista nuevoArtista = new Artista(idArtista, nombre, paisOrigen, descripcion);
    artistas.add(nuevoArtista);
    
    JOptionPane.showMessageDialog(null, "Artista creado");
    }
    
    public void obtenerArtistas(){
    int totalArtistas = artistas.size();
    
    if(totalArtistas == 0){
        JOptionPane.showMessageDialog(null, "No se han registrado artistas");
    } else {
        String listaCompleta = "";
        for(int i = 0; i< totalArtistas; i++){
            Artista ar = artistas.get(i);
            listaCompleta += "Nombre: " + ar.getNombre() + "\nPais Origen: " + ar.getPaisOrigen() + "\nDescripcion: " + ar.getDescripcion() + "\n";
    }
        JOptionPane.showMessageDialog(null, "LISTA DE ARTISTAS - CANTIDAD DE ARTISTAS " + totalArtistas + "\n" + listaCompleta);
    }
    }
    
    public Artista buscarArtista(String nombreBusqueda){
        if (nombreBusqueda == null){
            return null; 
        } else {
        String nombreLimpio = nombreBusqueda.trim();
        
        for(int i=0; i<this.artistas.size(); i++){
            Artista ar = this.artistas.get(i);
            if(ar.getNombre().equalsIgnoreCase(nombreLimpio)){
            return ar;
            }
        }
        return null;
        }
    }
    
    public void eliminarArtista(){
    String nombreBusqueda = JOptionPane.showInputDialog("Ingrese el nombre del artista que desea eliminar");
    
    Artista artistaAEliminar = buscarArtista(nombreBusqueda);
    
    if(artistaAEliminar != null){
        this.artistas.remove(artistaAEliminar);
        JOptionPane.showInputDialog("Artista " + artistaAEliminar.getNombre() + " eliminado de tu coleccion");
    }else{
        JOptionPane.showInputDialog("Error, artista: " + nombreBusqueda + " no encontrado");
    }
    }
    
    //ALBUMES
    
    public void crearAlbum() {
        String nombreArtista = JOptionPane.showInputDialog(
                "Ingrese el nombre del artista al que desea agregar el álbum"
        );
        Artista artista = buscarArtista(nombreArtista);

        if (artista == null) {
            JOptionPane.showMessageDialog(null, "Artista no encontrado");
            return;
        }

        int idAlbum = Integer.parseInt(JOptionPane.showInputDialog("Digite el id del álbum"));
        String titulo = JOptionPane.showInputDialog("Título del álbum");
        int anio = Integer.parseInt(JOptionPane.showInputDialog("Año de lanzamiento"));
        String genero = JOptionPane.showInputDialog("Género del álbum");

        Album album = new Album(idAlbum, titulo, anio, genero);
        artista.agregarAlbum(album);

        JOptionPane.showMessageDialog(null, "Álbum creado y agregado al artista " + artista.getNombre());
    }

    public void mostrarAlbumsDeArtista() {
        String nombreArtista = JOptionPane.showInputDialog("Ingrese el nombre del artista");
        Artista artista = buscarArtista(nombreArtista);

        if (artista == null) {
            JOptionPane.showMessageDialog(null, "Artista no encontrado");
            return;
        }

        artista.obtenerAlbums();
    }

    private Album buscarAlbumPorNombre(Artista artista, String tituloAlbum) {
        if (artista == null || tituloAlbum == null) {
            return null;
        }
        String limpio = tituloAlbum.trim();
        for (Album a : artista.getAlbums()) {
            if (a.getTitulo().equalsIgnoreCase(limpio)) {
                return a;
            }
        }
        return null;
    }

    public void eliminarAlbum() {
        String nombreArtista = JOptionPane.showInputDialog("Ingrese el nombre del artista");
        Artista artista = buscarArtista(nombreArtista);
        if (artista == null) {
            JOptionPane.showMessageDialog(null, "Artista no encontrado");
            return;
        }

        String tituloAlbum = JOptionPane.showInputDialog("Ingrese el título del álbum a eliminar");
        Album album = buscarAlbumPorNombre(artista, tituloAlbum);

        if (album != null) {
            artista.eliminarAlbum(album);
            JOptionPane.showMessageDialog(null, "Álbum eliminado");
        } else {
            JOptionPane.showMessageDialog(null, "Álbum no encontrado");
        }
    }

    //CANCIONES

    public void crearCancion() {
        String nombreArtista = JOptionPane.showInputDialog("Ingrese el nombre del artista");
        Artista artista = buscarArtista(nombreArtista);
        if (artista == null) {
            JOptionPane.showMessageDialog(null, "Artista no encontrado");
            return;
        }

        String tituloAlbum = JOptionPane.showInputDialog("Ingrese el título del álbum");
        Album album = buscarAlbumPorNombre(artista, tituloAlbum);
        if (album == null) {
            JOptionPane.showMessageDialog(null, "Álbum no encontrado");
            return;
        }

        int idCancion = Integer.parseInt(JOptionPane.showInputDialog("Id de la canción"));
        String titulo = JOptionPane.showInputDialog("Título de la canción");
        double duracion = Double.parseDouble(JOptionPane.showInputDialog("Duración en minutos"));
        String genero = JOptionPane.showInputDialog("Género de la canción");
        int pista = Integer.parseInt(JOptionPane.showInputDialog("Número de pista"));

        Cancion cancion = new Cancion(idCancion, titulo, duracion, genero, pista);
        album.agregarCancionAlbum(cancion);

        JOptionPane.showMessageDialog(null, "Canción agregada al álbum " + album.getTitulo());
    }

    public Cancion buscarCancion(String nombre) {
        if (nombre == null) {
            return null;
        }
        String limpio = nombre.trim();
        for (Artista artista : artistas) {
            for (Album album : artista.getAlbums()) {
                for (Cancion c : album.getListaCanciones()) {
                    if (c.getTitulo().equalsIgnoreCase(limpio)) {
                        return c;
                    }
                }
            }
        }
        return null;
    }

    //PLAYLISTS

    public void crearPlaylist() {
        int idPlaylist = Integer.parseInt(JOptionPane.showInputDialog("Digite el id de la playlist"));
        String nombre = JOptionPane.showInputDialog("Nombre de la playlist");
        String fechaCreacion = JOptionPane.showInputDialog("Digite la fecha de hoy");

        Playlist nuevaPlaylist = new Playlist(idPlaylist, nombre, fechaCreacion);
        playlists.add(nuevaPlaylist);

        JOptionPane.showMessageDialog(null, "Playlist creada");
    }

    private Playlist buscarPlaylistPorNombre(String nombre) {
        if (nombre == null) {
            return null;
        }
        String limpio = nombre.trim();
        for (Playlist p : playlists) {
            if (p.getNombre().equalsIgnoreCase(limpio)) {
                return p;
            }
        }
        return null;
    }

    public void obtenerPlaylists() {
        if (playlists.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No tienes playlists creadas");
        } else {
            String lista = "";
            for (int i = 0; i < playlists.size(); i++) {
                Playlist p = playlists.get(i);
                lista += (i + 1) + ". " + p.getNombre() + "\n";
            }
            JOptionPane.showMessageDialog(null, "TUS PLAYLISTS:\n" + lista);
        }
    }

    public void agregarCancionAPlaylist() {
        if (playlists.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No tienes playlists. Crea una primero.");
            return;
        }

        String nombrePlaylist = JOptionPane.showInputDialog("Nombre de la playlist");
        Playlist playlist = buscarPlaylistPorNombre(nombrePlaylist);
        if (playlist == null) {
            JOptionPane.showMessageDialog(null, "Playlist no encontrada");
            return;
        }

        String nombreCancion = JOptionPane.showInputDialog("Nombre de la canción que quieres agregar");
        Cancion cancion = buscarCancion(nombreCancion);
        if (cancion == null) {
            JOptionPane.showMessageDialog(null, "Canción no encontrada en tu biblioteca");
            return;
        }

        playlist.agregarCancionPlaylist(cancion);
        JOptionPane.showMessageDialog(null, "Canción agregada a la playlist " + playlist.getNombre());
    }

    public void quitarCancionDePlaylist() {
        String nombrePlaylist = JOptionPane.showInputDialog("Nombre de la playlist");
        Playlist playlist = buscarPlaylistPorNombre(nombrePlaylist);
        if (playlist == null) {
            JOptionPane.showMessageDialog(null, "Playlist no encontrada");
            return;
        }

        String nombreCancion = JOptionPane.showInputDialog("Nombre de la canción que quieres quitar");
        Cancion cancion = null;
        for (Cancion c : playlist.getCanciones()) {
            if (c.getTitulo().equalsIgnoreCase(nombreCancion.trim())) {
                cancion = c;
                break;
            }
        }

        if (cancion == null) {
            JOptionPane.showMessageDialog(null, "Canción no encontrada en esa playlist");
            return;
        }

        playlist.quitarCancionPlaylist(cancion);
        JOptionPane.showMessageDialog(null, "Canción eliminada de la playlist");
    }
}
