/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package musigest;

import java.util.ArrayList; 
import javax.swing.JOptionPane;
/**
 *
 * @author ea054
 */
public class Usuario extends Persona{
    
    private String fechaRegistro;
    private ArrayList<Artista> artistas;
    private ArrayList<Playlist> playlists;
    
    public Usuario(int id, String nombre, String correo, String contrasena, String fechaRegistro){
    super(id, nombre, correo, contrasena);
    this.fechaRegistro = fechaRegistro;
    this.artistas = new ArrayList<>();
    this.playlists = new ArrayList<>();
    }
    
    public String getFechaRegistro() {
    return fechaRegistro;
    }
    
    public void crearArtista(){
    int idArtista = Integer.parseInt(JOptionPane.showInputDialog("Digite el id del artista"));
    String nombre = JOptionPane.showInputDialog("Nombre del nuevo artista");
    String paisOrigen = JOptionPane.showInputDialog("Pais de origen del nuevo artista");
    String descripcion = JOptionPane.showInputDialog("Descripcion del nuevo artista");
    
    Artista nuevoArtista = new Artista(idArtista, nombre, paisOrigen, descripcion);
    artistas.add(nuevoArtista);
    
    JOptionPane.showMessageDialog(null, "Artista creado");
    }
    
    public void obtenerArtistas(){
    int totalArtistas = artistas.size();
    
    if(totalArtistas == 0){
        JOptionPane.showMessageDialog(null, "No se han registrado artistas");
    } else {
        String listaCompleta = "";
        for(int i = 0; i< totalArtistas; i++){
            Artista ar = artistas.get(i);
            listaCompleta += "Nombre: " + ar.getNombre() + "\nPais Origen: " + ar.getPaisOrigen() + "\nDescripcion: " + ar.getDescripcion() + "\n";
    }
        JOptionPane.showMessageDialog(null, "LISTA DE ARTISTAS - CANTIDAD DE ARTISTAS " + totalArtistas + "\n" + listaCompleta);
    }
    }
    
    public Artista buscarArtista(String nombreBusqueda){
        if (nombreBusqueda == null){
            return null; 
        } else {
        String nombreLimpio = nombreBusqueda.trim();
        
        for(int i=0; i<this.artistas.size(); i++){
            Artista ar = this.artistas.get(i);
            if(ar.getNombre().equalsIgnoreCase(nombreLimpio)){
            return ar;
            }
        }
        return null;
        }
    }
    
    public void eliminarArtista(){
    String nombreBusqueda = JOptionPane.showInputDialog("Ingrese el nombre del artista que desea eliminar");
    
    Artista artistaAEliminar = buscarArtista(nombreBusqueda);
    
    if(artistaAEliminar != null){
        this.artistas.remove(artistaAEliminar);
        JOptionPane.showInputDialog("Artista " + artistaAEliminar.getNombre() + " eliminado de tu coleccion");
    }else{
        JOptionPane.showInputDialog("Error, artista: " + nombreBusqueda + " no encontrado");
    }
    }
    
    public void buscarAlbum(Artista artista){
    ArrayList<Album> albums = artista.getAlbums();  
        if (albums.isEmpty()){
            JOptionPane.showMessageDialog(null, "El artista no tiene albumes registrados");
        }else{
            String lista = "";
            for(int i=0; i<albums.size(); i++){
            Album a = albums.get(i);
            lista += (i + 1) + ". " + a.getTitulo() + " (" + a.getAnioLanzamiento() + ")\n";
        }
            JOptionPane.showMessageDialog(null, lista);
        }
}
    
    
    
    
    
    
    
    public void crearPlaylist(){
    int idPlaylist = Integer.parseInt(JOptionPane.showInputDialog("Digite el id de la playlist"));
    String nombre = JOptionPane.showInputDialog("Nombre del nuevo artista");
    String fechaCreacion = JOptionPane.showInputDialog("Digite la fecha de hoy");
    
    Playlist nuevaPlaylist = new Playlist(idPlaylist, nombre, fechaCreacion);
    playlists.add(nuevaPlaylist);
    
    JOptionPane.showMessageDialog(null, "Playlist creada");
    }
    
}
