/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package musigest;

/**
 *
 * @author ea054
 */
import javax.swing.JOptionPane;

public class Principal {

    public static void main(String[] args) {

        // Único administrador del sistema
        Administrador admin = new Administrador(1, "Administrador", "admin@musigest.com", "admin123", "2024-11-28");

        boolean salir = false;
        while (!salir) {
            String opcionStr = JOptionPane.showInputDialog(
                    "Bienvenido a MusiGest\n\n1. Iniciar sesión\n2. Salir\n\nSeleccione una opción:");
            if (opcionStr == null) { // cerró la ventana
                salir = true;
                continue;
            }

            int opcion;
            try {
                opcion = Integer.parseInt(opcionStr);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Opción no válida");
                continue;
            }

            switch (opcion) {
                case 1:
                    iniciarSesion(admin);
                    break;
                case 2:
                    salir = true;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida");
            }
        }

        JOptionPane.showMessageDialog(null, "Gracias por usar MusiGest");
    }

    private static void iniciarSesion(Administrador admin) {
        String correo = JOptionPane.showInputDialog("Correo:");
        String contrasena = JOptionPane.showInputDialog("Contraseña:");
        if (correo == null || contrasena == null) return;

        // 1. Verificar si es el administrador
        if (correo.equalsIgnoreCase(admin.getCorreo()) && contrasena.equals(admin.getContrasena())) {
            admin.iniciarSesion();
            menuAdministrador(admin);
            admin.cerrarSesion();
            return;
        }

        // 2. Buscar usuario en la lista del admin
        Usuario usuarioEncontrado = null;
        for (Usuario u : admin.getListaUsuarios()) {
            if (correo.equalsIgnoreCase(u.getCorreo()) && contrasena.equals(u.getContrasena())) {
                usuarioEncontrado = u;
                break;
            }
        }

        // 3. Si lo encuentra → menú usuario
        if (usuarioEncontrado != null) {
            usuarioEncontrado.iniciarSesion();
            menuUsuario(usuarioEncontrado);
            usuarioEncontrado.cerrarSesion();
        } else {
            // 4. Ofrecer registro
            int resp = JOptionPane.showConfirmDialog(
                    null,
                    "Usuario no registrado.\n¿Deseas crear una cuenta?",
                    "Registro",
                    JOptionPane.YES_NO_OPTION
            );
            if (resp == JOptionPane.YES_OPTION) admin.crearUsuario();
        }
    }

    private static void menuAdministrador(Administrador admin) {
        boolean salir = false;
        while (!salir) {
            String opcionStr = JOptionPane.showInputDialog(
                    "MENÚ ADMINISTRADOR\n\n1. Crear usuario\n2. Ver usuarios\n3. Cerrar sesión\n\nSeleccione una opción:");
            if (opcionStr == null) return;

            int opcion;
            try {
                opcion = Integer.parseInt(opcionStr);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Opción no válida");
                continue;
            }

            switch (opcion) {
                case 1:
                    admin.crearUsuario();
                    break;
                case 2:
                    admin.obtenerUsuarios();
                    break;
                case 3:
                    salir = true;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida");
            }
        }
    }

    private static void menuUsuario(Usuario usuario) {
        boolean salir = false;
        while (!salir) {
            String opcionStr = JOptionPane.showInputDialog(
                    "MENÚ USUARIO\n\n1. Crear artista\n2. Ver artistas\n3. Eliminar artista\n4. Crear álbum\n5. Ver álbumes de un artista\n6. Crear canción\n7. Crear playlist\n8. Ver playlists\n9. Agregar canción a playlist\n10. Quitar canción de playlist\n11. Cerrar sesión\n\nSeleccione una opción:");
            if (opcionStr == null) return;

            int opcion;
            try {
                opcion = Integer.parseInt(opcionStr);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Opción no válida");
                continue;
            }

            switch (opcion) {
                case 1:
                    usuario.crearArtista();
                    break;
                case 2:
                    usuario.obtenerArtistas();
                    break;
                case 3:
                    usuario.eliminarArtista();
                    break;
                case 4:
                    usuario.crearAlbum();
                    break;
                case 5:
                    usuario.mostrarAlbumsDeArtista();
                    break;
                case 6:
                    usuario.crearCancion();
                    break;
                case 7:
                    usuario.crearPlaylist();
                    break;
                case 8:
                    usuario.obtenerPlaylists();
                    break;
                case 9:
                    usuario.agregarCancionAPlaylist();
                    break;
                case 10:
                    usuario.quitarCancionDePlaylist();
                    break;
                case 11:
                    salir = true;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida");
            }
        }
    }
}
