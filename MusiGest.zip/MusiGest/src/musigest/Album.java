/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package musigest;
/**
 *
 * @author ACCN0
 */
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class Album {
    private int idAlbum;
    private String titulo;
    private int anioLanzamiento;
    private String genero;
    private Artista artista;
    private ArrayList<Cancion> listaCanciones;

    public Album(Integer idAlbum, String titulo, Integer anioLanzamiento, String genero) {
        this.idAlbum = idAlbum;
        this.titulo = titulo;
        this.anioLanzamiento = anioLanzamiento;
        this.genero = genero;
        this.artista = artista;
        this.listaCanciones = new ArrayList<>();
    }

    public int getIdAlbum() {
        return idAlbum;
    }

    public String getTitulo() {
        return titulo;
    }

    public int getAnioLanzamiento() {
        return anioLanzamiento;
    }

    public String getGenero() {
        return genero;
    }
    
    public Artista getArtista(){
    return artista;
    }
    
    public ArrayList<Cancion> getListaCanciones(){
    return listaCanciones;
    }
    
    public void agregarCancionAlbum(Cancion cancion){
    this.listaCanciones.add(cancion);
    }
    
    public void listarCanciones(){
    String listaCan = "";
    for(int i=0;i< listaCanciones.size(); i++){
        Cancion c = listaCanciones.get(i);
        listaCan += (1 + i) + ". " + c.getTitulo() + " (" + c.getDuracion() + " min)\n";
    }
    JOptionPane.showMessageDialog(null, listaCan);
    }
    
}
