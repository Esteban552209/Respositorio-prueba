/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package musigest;

import java.util.ArrayList; // Para poder hacer listas
import javax.swing.JOptionPane;
/**
 *
 * @author ea054
 */
public class Administrador extends Persona{
    
    private String fechaDeAdmin;
    private ArrayList<Usuario> listaUsuarios;
    
    public Administrador(int id, String nombre, String correo, String contrasena, String fechaDeAdmin){
    super(id, nombre, correo, contrasena);
    this.fechaDeAdmin = fechaDeAdmin;
    this.listaUsuarios = new ArrayList<>();
    }
    
    public void crearUsuario(){
    int id = Integer.parseInt(JOptionPane.showInputDialog("Digite el id del usuario"));
    String nombre = JOptionPane.showInputDialog("Nombre del nuevo usuario");
    String correo = JOptionPane.showInputDialog("Correo del nuevo usuario");
    String contrasena = JOptionPane.showInputDialog("contrasena del nuevo usuario");
    String fechaRegistro = JOptionPane.showInputDialog("Digite la fecha del registro");
    
    Usuario nuevoUsuario = new Usuario(id, nombre, correo, contrasena, fechaRegistro);
    listaUsuarios.add(nuevoUsuario);
    
    JOptionPane.showMessageDialog(null, "Usuario registrado");
    }
    
    public void obtenerUsuarios(){
    int totalUsuarios = listaUsuarios.size();
    
    if(totalUsuarios == 0){
        JOptionPane.showMessageDialog(null, "No se han registrado usuarios");
    } else {
        String listaCompleta = "";
        for(int i = 0; i< totalUsuarios; i++){
            Usuario us = listaUsuarios.get(i);
            listaCompleta += "ID: " + us.getId() + "\n" + "Nombre: " + us.getNombre() + "\nCorreo: " + us.getCorreo() +"\nContraseña: " + us.getContrasena() + "\nFecha de registro: " + us.getFechaRegistro() + "\n";
    }
        JOptionPane.showMessageDialog(null, "LISTA DE USUARIOS - CANTIDAD DE USUARIOS " + totalUsuarios + "\n" + listaCompleta);
    }
    }
}
